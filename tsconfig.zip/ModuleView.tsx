import React, { useState } from 'react';
import { Module, Language } from './types';
import { Button } from './ui';

export const ModuleView: React.FC<{
    module: Module;
    onSave: (moduleId: string, newTitle: string, newContent: string) => void;
    t: (k: string) => string;
    lang: Language;
}> = ({ module, onSave, t, lang }) => {
    const [title, setTitle] = useState(module.customTitles[lang] || t(module.defaultTitleKey));
    const [content, setContent] = useState(module.content[lang] || '');
    const [isSaved, setIsSaved] = useState(false);
    
    const handleSave = () => {
        onSave(module.id, title, content);
        setIsSaved(true);
        setTimeout(() => setIsSaved(false), 2000);
    };

    return (
        <section className="col-span-12 lg:col-span-8">
            <div className="flex h-full flex-col gap-4 rounded-xl border border-slate-200 dark:border-brand-line bg-white dark:bg-brand-panel p-4">
                <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-sky-100 text-3xl dark:bg-sky-500/20">{module.icon}</div>
                    <input 
                        type="text" 
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="w-full bg-transparent text-xl font-bold text-slate-800 outline-none transition-all dark:text-brand-text border-b-2 border-transparent focus:border-sky-500"
                        title={t('editTitle')}
                    />
                    <div className="flex items-center gap-2">
                         {isSaved && <span className="text-sm text-green-600 dark:text-green-400 animate-pulse">{t('contentSaved')}</span>}
                         <Button onClick={handleSave} className="border-green-300 bg-green-100 text-green-800 hover:bg-green-200 font-bold dark:border-green-500/50 dark:bg-green-500/20 dark:text-green-300 dark:hover:bg-green-500/30">
                            💾 {t('saveContent')}
                         </Button>
                    </div>
                </div>
                
                <div className="flex-grow">
                    <textarea 
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        placeholder={t('moduleContentPlaceholder')}
                        className="h-full w-full resize-none rounded-lg border border-slate-200 bg-slate-50 p-3 font-mono text-sm leading-relaxed outline-none focus:border-sky-500 dark:border-brand-line dark:bg-brand-card"
                    />
                </div>
            </div>
        </section>
    );
};
